
public class EntityType {

}
