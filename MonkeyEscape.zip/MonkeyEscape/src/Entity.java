
public class Entity {

}
