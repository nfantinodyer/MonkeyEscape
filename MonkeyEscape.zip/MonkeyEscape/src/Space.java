
public class Space {

}
